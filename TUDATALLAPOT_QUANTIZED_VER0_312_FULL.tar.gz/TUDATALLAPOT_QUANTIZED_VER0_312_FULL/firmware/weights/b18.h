//Numpy array shape [5]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 5

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
bias18_t b18[5];
#else
bias18_t b18[5] = {0, 0, 0, 0, 0};
#endif

#endif
