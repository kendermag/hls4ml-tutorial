//Numpy array shape [5]
//Min 0.620815932751
//Max 1.156938791275
//Number of zeros 0

#ifndef S20_H_
#define S20_H_

#ifndef __SYNTHESIS__
batch_normalization_4_scale_t s20[5];
#else
batch_normalization_4_scale_t s20[5] = {0.7088112235, 0.6208159328, 1.1569387913, 1.0394792557, 0.7636910677};
#endif

#endif
