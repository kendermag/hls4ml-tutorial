//Numpy array shape [5]
//Min -1.789750456810
//Max 8.012669563293
//Number of zeros 0

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
batch_normalization_4_bias_t b20[5];
#else
batch_normalization_4_bias_t b20[5] = {2.2097036839, 2.6184790134, -1.7897504568, 8.0126695633, 2.1888513565};
#endif

#endif
