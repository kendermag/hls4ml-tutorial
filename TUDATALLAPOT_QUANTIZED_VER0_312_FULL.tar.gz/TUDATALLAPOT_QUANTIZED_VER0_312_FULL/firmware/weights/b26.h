//Numpy array shape [3]
//Min -0.327173560858
//Max 0.264190465212
//Number of zeros 0

#ifndef B26_H_
#define B26_H_

#ifndef __SYNTHESIS__
dense_bias_t b26[3];
#else
dense_bias_t b26[3] = {0.0509131067, 0.2641904652, -0.3271735609};
#endif

#endif
