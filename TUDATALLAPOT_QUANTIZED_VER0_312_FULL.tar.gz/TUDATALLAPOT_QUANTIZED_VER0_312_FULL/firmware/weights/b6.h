//Numpy array shape [10]
//Min -0.375000000000
//Max 0.156250000000
//Number of zeros 1

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
bias6_t b6[10];
#else
bias6_t b6[10] = {0.96875, 0.81250, -1.00000, -0.68750, 0.06250, -1.00000, 0.12500, -0.18750, -1.00000, -0.25000};
#endif

#endif
