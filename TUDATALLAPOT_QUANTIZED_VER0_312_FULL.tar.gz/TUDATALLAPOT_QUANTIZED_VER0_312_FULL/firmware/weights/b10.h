//Numpy array shape [10]
//Min -0.312500000000
//Max 0.125000000000
//Number of zeros 1

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[10];
#else
bias10_t b10[10] = {-1.00000, -0.28125, 0.78125, -1.00000, -0.59375, 0.87500, -1.00000, -0.62500, -0.09375, 0.96875};
#endif

#endif
