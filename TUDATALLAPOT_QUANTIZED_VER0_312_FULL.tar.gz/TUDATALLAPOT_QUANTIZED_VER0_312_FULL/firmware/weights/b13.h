//Numpy array shape [12]
//Min -0.156250000000
//Max 0.125000000000
//Number of zeros 3

#ifndef B13_H_
#define B13_H_

#ifndef __SYNTHESIS__
bias13_t b13[12];
#else
bias13_t b13[12] = {0.75000, 0.37500, 0.46875, 0.50000, 0.37500, -0.43750, -0.06250, 0.00000, -1.00000, 0.06250, -0.18750, -0.50000};
#endif

#endif
